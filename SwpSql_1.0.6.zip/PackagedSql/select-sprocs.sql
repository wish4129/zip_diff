GO
PRINT N'Creating [sdowner].[Allowance_Select]...';


GO
IF EXISTS(SELECT * FROM sys.objects WHERE type = 'P' AND NAME='Allowance_Select')
    DROP PROCEDURE [sdowner].[Allowance_Select]

GO

-- --------------------------------------------------------------------------------
--  Copyright Scientia Ltd.
--
--  All rights are reserved.  Reproduction or transmission in whole or in part, in 
--  any form or by any means, electronic, mechanical, or otherwise, is prohibited
--  without the prior written consent of the copyright owner.
-- --------------------------------------------------------------------------------

CREATE PROCEDURE [sdowner].[Allowance_Select]
	 @DepartmentName		VARCHAR(255) = NULL,
	 @StaffHostkey			VARCHAR(255) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	SELECT 
	  Id						= allow.Id						, 
	  Description				= allow.Description				, 
	  LinkedObjectId			= allow.LinkedObjectId			, 
	  AllowanceTypeId			= allow.AllowanceTypeId			, 
	  AllowanceTypeName			= atype.Name					, 
	  Value						= allow.Value					, 
	  WeekPattern				= allow.WeekPattern				, 
	  Multiplier				= allow.Multiplier				, 
	  Total						= allow.Total					, 
	  TotalMultiplier			= allow.TotalMultiplier			, 
	  DepartmentId				= allow.DepartmentId			, 
	  DepartmentName			= dept.Name						, 
	  AllowanceTemplateId		= allow.AllowanceTemplateId		, 
	  AllowanceTemplateName		= atemp.Name					, 
	  Notes						= allow.Notes					, 
	  LinkedObjectName			= allow.LinkedObjectName		, 
	  LinkedObjectDescription	= allow.LinkedObjectDescription	, 
	  StaffId					= allow.StaffId					,
	  StaffHostkey				= stf.HostKey					
	FROM 
	  sdowner.SPV_ALLOWANCE allow 
	  LEFT JOIN sdowner.SP_ALLOWANCETYPE atype ON allow.AllowanceTypeId = atype.Id
	  LEFT JOIN sdowner.SP_ALLOWANCETEMPLATE atemp ON allow.AllowanceTemplateId = atemp.Id
	  LEFT JOIN sdowner.SPV_DEPARTMENT dept ON allow.DepartmentId = dept.Id
	  LEFT JOIN sdowner.SPV_STAFF stf ON allow.StaffId = stf.Id
	WHERE (@DepartmentName IS NULL OR dept.Name = @DepartmentName)
		AND (@StaffHostkey IS NULL OR stf.HostKey = @StaffHostkey)
END